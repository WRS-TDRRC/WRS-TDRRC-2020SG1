import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG2", "AGXSimulator", "DoubleArmV7A")
