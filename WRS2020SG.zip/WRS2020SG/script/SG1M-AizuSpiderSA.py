import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG1M", "AGXSimulator", "AizuSpiderSA")
