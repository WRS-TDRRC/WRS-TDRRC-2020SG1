import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG2", [ "AGXSimulator", "AISTSimulator" ], "Quadcopter",
    enableMulticopterSimulation = True)
