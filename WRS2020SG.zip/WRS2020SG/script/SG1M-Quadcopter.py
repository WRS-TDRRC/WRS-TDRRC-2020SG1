import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG1M", [ "AGXSimulator", "AISTSimulator" ], "Quadcopter",
    enableMulticopterSimulation = True)
