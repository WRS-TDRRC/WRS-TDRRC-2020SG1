import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG1L", "AGXSimulator", "DoubleArmV7A")
