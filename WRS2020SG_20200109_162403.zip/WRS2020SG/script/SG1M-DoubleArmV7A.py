import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "SG1M", "AGXSimulator", "DoubleArmV7A")
